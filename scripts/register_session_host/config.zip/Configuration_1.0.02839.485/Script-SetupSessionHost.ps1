<#

.SYNOPSIS
Set up a VM as session host to existing/new host pool.

.DESCRIPTION
This script installs RD agent and verify that it is successfully registered as session host to existing/new host pool.

#>
param(
    [Parameter(mandatory = $true)]
    [string]$HostPoolName,

    [Parameter(Mandatory = $false)]
    [string]$RegistrationInfoToken="",

    [Parameter(mandatory = $false)] 
    [pscredential]$RegistrationInfoTokenCredential = $null,

    [Parameter(Mandatory = $false)]
    [bool]$AadJoin = $false,

    [Parameter(Mandatory = $false)]
    [bool]$AadJoinPreview = $false,

    [Parameter(Mandatory = $false)]
    [string]$MdmId = "",

    [Parameter(Mandatory = $false)]
    [string]$SessionHostConfigurationLastUpdateTime = "",

    [Parameter(mandatory = $false)] 
    [switch]$EnableVerboseMsiLogging,
    
    [Parameter(Mandatory = $false)]
    [bool]$UseAgentDownloadEndpoint = $false
)
$ScriptPath = [system.io.path]::GetDirectoryName($PSCommandPath)

# Dot sourcing Functions.ps1 file
. (Join-Path $ScriptPath "Functions.ps1")
. (Join-Path $ScriptPath "AvdFunctions.ps1")

# Setting ErrorActionPreference to stop script execution when error occurs
$ErrorActionPreference = "Stop"

# Checking if RDInfragent is registered or not in rdsh vm
Write-Log -Message "Checking whether VM was Registered with RDInfraAgent"
$RegistryCheckObj = IsRDAgentRegistryValidForRegistration

$RegistrationInfoTokenValue = ""
if ($null -eq $RegistrationInfoTokenCredential) {
    $RegistrationInfoTokenValue = $RegistrationInfoToken
} else {
    $RegistrationInfoTokenValue = $RegistrationInfoTokenCredential.GetNetworkCredential().Password
}

if ($RegistryCheckObj.result)
{
    Write-Log -Message "VM was already registered with RDInfraAgent, script execution was stopped"
}
else
{
    Write-Log -Message "Creating a folder inside rdsh vm for extracting deployagent zip file"
    $DeployAgentLocation = "C:\DeployAgent"
    ExtractDeploymentAgentZipFile -ScriptPath $ScriptPath -DeployAgentLocation $DeployAgentLocation

    Write-Log -Message "Changing current folder to Deployagent folder: $DeployAgentLocation"
    Set-Location "$DeployAgentLocation"

    Write-Log -Message "VM not registered with RDInfraAgent, script execution will continue"

    Write-Log "AgentInstaller is $DeployAgentLocation\RDAgentBootLoaderInstall, InfraInstaller is $DeployAgentLocation\RDInfraAgentInstall"

    if ($AadJoinPreview) {
        Write-Log "Azure ad join preview flag enabled"
        $registryPath = "HKLM:\SOFTWARE\Microsoft\RDInfraAgent\AzureADJoin"
        if (Test-Path -Path $registryPath) {
            Write-Log "Setting reg key JoinAzureAd"
            New-ItemProperty -Path $registryPath -Name JoinAzureAD -PropertyType DWord -Value 0x01
        } else {
            Write-Log "Creating path for azure ad join registry keys: $registryPath"
            New-item -Path $registryPath -Force | Out-Null
            Write-Log "Setting reg key JoinAzureAD"
            New-ItemProperty -Path $registryPath -Name JoinAzureAD -PropertyType DWord -Value 0x01
        }
        if ($MdmId) {
            Write-Log "Setting reg key MDMEnrollmentId"
            New-ItemProperty -Path $registryPath -Name MDMEnrollmentId -PropertyType String -Value $MdmId
        }
    }

    InstallRDAgents -AgentBootServiceInstallerFolder "$DeployAgentLocation\RDAgentBootLoaderInstall" -AgentInstallerFolder "$DeployAgentLocation\RDInfraAgentInstall" -RegistrationToken $RegistrationInfoTokenValue -EnableVerboseMsiLogging:$EnableVerboseMsiLogging -UseAgentDownloadEndpoint $UseAgentDownloadEndpoint

    Write-Log -Message "The agent installation code was successfully executed and RDAgentBootLoader, RDAgent installed inside VM for existing hostpool: $HostPoolName"
}

Write-Log -Message "Session Host Configuration Last Update Time: $SessionHostConfigurationLastUpdateTime"
$rdInfraAgentRegistryPath = "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDInfraAgent"
if (Test-path $rdInfraAgentRegistryPath) {
    Write-Log -Message ("Write SessionHostConfigurationLastUpdateTime '$SessionHostConfigurationLastUpdateTime' to $rdInfraAgentRegistryPath")
    Set-ItemProperty -Path $rdInfraAgentRegistryPath -Name "SessionHostConfigurationLastUpdateTime" -Value $SessionHostConfigurationLastUpdateTime
}

if ($AadJoin -and -not $AadJoinPreview) {
    # 6 Minute sleep to guarantee intune metadata logging
    Write-Log -Message ("Configuration.ps1 complete, sleeping for 6 minutes")
    Start-Sleep -Seconds 360
    Write-Log -Message ("Configuration.ps1 complete, waking up from 6 minute sleep")
}

$SessionHostName = GetAvdSessionHostName
Write-Log -Message "Successfully registered VM '$SessionHostName' to HostPool '$HostPoolName'"
# SIG # Begin signature block
# MIIlJAYJKoZIhvcNAQcCoIIlFTCCJRECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUwiuePe/VTIfXraFAY66sm2OS
# Rsaggh9PMIIFjTCCBHWgAwIBAgIQDpsYjvnQLefv21DiCEAYWjANBgkqhkiG9w0B
# AQwFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVk
# IElEIFJvb3QgQ0EwHhcNMjIwODAxMDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQsw
# CQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cu
# ZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz
# 7MKnJS7JIT3yithZwuEppz1Yq3aaza57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS
# 5F/WBTxSD1Ifxp4VpX6+n6lXFllVcq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7
# bXHiLQwb7iDVySAdYyktzuxeTsiT+CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfI
# SKhmV1efVFiODCu3T6cw2Vbuyntd463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jH
# trHEtWoYOAMQjdjUN6QuBX2I9YI+EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14
# Ztk6MUSaM0C/CNdaSaTC5qmgZ92kJ7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2
# h4mXaXpI8OCiEhtmmnTK3kse5w5jrubU75KSOp493ADkRSWJtppEGSt+wJS00mFt
# 6zPZxd9LBADMfRyVw4/3IbKyEbe7f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPR
# iQfhvbfmQ6QYuKZ3AeEPlAwhHbJUKSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ER
# ElvlEFDrMcXKchYiCd98THU/Y+whX8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4K
# Jpn15GkvmB0t9dmpsh3lGwIDAQABo4IBOjCCATYwDwYDVR0TAQH/BAUwAwEB/zAd
# BgNVHQ4EFgQU7NfjgtJxXWRM3y5nP+e6mK4cD08wHwYDVR0jBBgwFoAUReuir/SS
# y4IxLVGLp6chnfNtyA8wDgYDVR0PAQH/BAQDAgGGMHkGCCsGAQUFBwEBBG0wazAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAC
# hjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURS
# b290Q0EuY3J0MEUGA1UdHwQ+MDwwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0
# LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwEQYDVR0gBAowCDAGBgRV
# HSAAMA0GCSqGSIb3DQEBDAUAA4IBAQBwoL9DXFXnOF+go3QbPbYW1/e/Vwe9mqyh
# hyzshV6pGrsi+IcaaVQi7aSId229GhT0E0p6Ly23OO/0/4C5+KH38nLeJLxSA8hO
# 0Cre+i1Wz/n096wwepqLsl7Uz9FDRJtDIeuWcqFItJnLnU+nBgMTdydE1Od/6Fmo
# 8L8vC6bp8jQ87PcDx4eo0kxAGTVGamlUsLihVo7spNU96LHc/RzY9HdaXFSMb++h
# UD38dglohJ9vytsgjTVgHAIDyyCwrFigDkBjxZgiwbJZ9VVrzyerbHbObyMt9H5x
# aiNrIv8SuFQtJ37YOtnwtoeW/VvRXKwYw02fc7cBqZ9Xql4o4rmUMIIFpDCCA4yg
# AwIBAgITdAAAABpPBOS2mfHAGQAAAAAAGjANBgkqhkiG9w0BAQsFADBYMQswCQYD
# VQQGEwJHQjESMBAGA1UECBMJSGFtcHNoaXJlMQ0wCwYDVQQHEwRIb29rMQ4wDAYD
# VQQKEwVTZXJjbzEWMBQGA1UEAxMNU2VyY28gUm9vdCBDQTAeFw0yMjA2MDkxMDE2
# MzNaFw0yNzA2MDkxMDI2MzNaMGMxCzAJBgNVBAYTAkdCMRIwEAYDVQQIEwlIYW1w
# c2hpcmUxDTALBgNVBAcTBEhvb2sxFjAUBgNVBAoTDVNlcmNvIExpbWl0ZWQxGTAX
# BgNVBAMTEFNlcmNvIElzc3VpbmcgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQDAtf9WJtHH7DloaVM0zB1GDEALn3dDd86dBXRZ9cctclEWSsmr1kY3
# yf2Ew8agE8QSeQUZcYZ/S8mlPAVE9fTpDUn92b5t2GwC66orDq5kvffmI6AshAAg
# N38AgPi/hjsxVh9zhaxWoAdT2xLPQkCRb6fAqwYfsw6LZ+x+qZuxkGH9Yljof/6N
# zG67nNt1FX0gvNG/321oEP5debj3GI0YNLFwI3sjCB8GH0O6lxht67Ei/8Rrnlii
# O36uUQb1eu48jzmTEeG7f2eBHlPeWUpgOaxp8kuu3lr7DEje94sZLoUJH8k6jgLG
# ikwXPtuU/Nc9ZDMLbs/ExD/Zn+PSFdBxAgMBAAGjggFaMIIBVjASBgkrBgEEAYI3
# FQEEBQIDAgACMCMGCSsGAQQBgjcVAgQWBBT3gaQvzowOaVbp+y3c1gvaOZfjYjAd
# BgNVHQ4EFgQUopXkhtwaDrY4TYaDWoCALa/cfDcwGQYJKwYBBAGCNxQCBAweCgBT
# AHUAYgBDAEEwDgYDVR0PAQH/BAQDAgEGMBIGA1UdEwEB/wQIMAYBAf8CAQAwHwYD
# VR0jBBgwFoAURolT3VYsBjsVcN3hsf2ipkZICcAwNgYDVR0fBC8wLTAroCmgJ4Yl
# aHR0cDovL2NybC5zZXJjby5jb20vcGtpL3NlcmNvaWNhLmNybDBkBggrBgEFBQcB
# AQRYMFYwIQYIKwYBBQUHMAGGFWh0dHA6Ly9vY3NwLnNlcmNvLmNvbTAxBggrBgEF
# BQcwAoYlaHR0cDovL2NybC5zZXJjby5jb20vcGtpL3NlcmNvaWNhLmNydDANBgkq
# hkiG9w0BAQsFAAOCAgEAAVK7Zv3vR1Kh+g/NSAH30qVBtZwGjtGGGyqLLdqF5i/e
# 0FQVWpIalwheMbsGwcg//3hUgbKYgtiNcQSXJdgxCPa2LQFYgRGLhgYqpzr5smw9
# Lr3fg0uV1TJ3Y9eW3ucF0BSPjS2LHey0iSNODQjfdkiV3sjJx5tzCcPA3+FcQmRs
# xIHXcmAh4slCNUbJSrQarbGE/LXnox/YFxUjMOHDaWc4ocEBf+OGLpO5fuoEtoxK
# S/yBqS7y6f4ULM9SxYmVMjqn8U6z/BTSWqn/twKbmnqEkjM2SKzmBoy833xXJW8G
# qTuynBE+dvlWK1jgtVIAPqEXksDTU643Cnm46oFjGPWjnM8HvA/O2h4gbd0bQ/pF
# nec8aMujwIXEr3dJNXJ/e9YOWlQm3aTGaaFLuW5N+yD4r6y7YyP0DLsT2/MQbeBx
# cb9mNU/WWA+SMVfBUxkKfho097X0tdwSrNjSGK+BfwjVWvMBXF+xVg3AS75ajD28
# 5fbJWcOp/vlb/xLjR7R5E38rFg2bpLbMWheuoZU51F8kh/ho9MjMT07mxCdgqD9g
# GLjAbE5jmZcdS6jG/ShRJAkQG0kBDqdowMayYv+WytUJPA0IL4QM0Q1sf19BEHYT
# hggb6jZmAh+iWQdUmym5MRSb2WdAV7SPP0s+w2umte3SKZtcuVHNKynBp74ExCYw
# ggagMIIFiKADAgECAhNvAAuao/iVbpyEsevtAAIAC5qjMA0GCSqGSIb3DQEBCwUA
# MGMxCzAJBgNVBAYTAkdCMRIwEAYDVQQIEwlIYW1wc2hpcmUxDTALBgNVBAcTBEhv
# b2sxFjAUBgNVBAoTDVNlcmNvIExpbWl0ZWQxGTAXBgNVBAMTEFNlcmNvIElzc3Vp
# bmcgQ0EwHhcNMjQxMDE0MTM0NzI2WhcNMjYxMDE0MTM0NzI2WjCBpjETMBEGCgmS
# JomT8ixkARkWA2NvbTEVMBMGCgmSJomT8ixkARkWBXNlcmNvMRIwEAYKCZImiZPy
# LGQBGRYCYWQxFzAVBgNVBAsTDkFkbWluaXN0cmF0aW9uMRkwFwYDVQQLExBTZXJ2
# aWNlIEFjY291bnRzMRowGAYDVQQLExFDeWJlckFyayBBY2NvdW50czEUMBIGA1UE
# AxMLQ1lBLWhzYW5kaHUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDt
# QSJKVFfrt6XVZdqtkCLASSvo+VTV4tDAlUjk2Bqe3VL86GUPo7sDLHBMqVno7iad
# Ib8OjnyRDlEpzi972GxSxfJR+qYAZetnN1ei6aBMlf5sk7++LnokK0geNvdn+a30
# pf9PZlZ9BV2h9jcc+o7KWeerf+s7Tjui0l2cP2SgOat6UBVq0pPYLC3D8YIQXXkB
# 1VgPyJfIfKTXgo5Abxvm/4DM6vfovq14AIvouxemKl+D72DgCdkvZ4VKqBm+/xeK
# zv+ajO5p6pjOeXsIJioppxKZsnmWrDYLjQTdKfey4hoY665jbQQBPB5pdeAg4lc9
# XRGBUY+dD7NrpgFqoo+NAgMBAAGjggMHMIIDAzA8BgkrBgEEAYI3FQcELzAtBiUr
# BgEEAYI3FQiB/cN8hvGYZ4GxhQWH8rBJhvjmBzeHutB3ysIpAgFkAgEdMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMDMAsGA1UdDwQEAwIHgDAbBgkrBgEEAYI3FQoEDjAMMAoG
# CCsGAQUFBwMDME8GCSsGAQQBgjcZAgRCMECgPgYKKwYBBAGCNxkCAaAwBC5TLTEt
# NS0yMS0xMTkyMjUwOTM1LTM2OTc4MzQzLTM5NDU5OTc2NzctNzc0MzMzMDAGA1Ud
# EQQpMCegJQYKKwYBBAGCNxQCA6AXDBVDWUEtaHNhbmRodUBzZXJjby5jb20wHQYD
# VR0OBBYEFGYf+t3epHraX3XW2J6ik8miwB1gMB8GA1UdIwQYMBaAFKKV5IbcGg62
# OE2Gg1qAgC2v3Hw3MIIBHAYDVR0fBIIBEzCCAQ8wggELoIIBB6CCAQOGgcpsZGFw
# Oi8vL0NOPVNlcmNvJTIwSXNzdWluZyUyMENBKDIpLENOPVNDT1NHVEM1UEVDQTEw
# MSxDTj1DRFAsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMs
# Q049Q29uZmlndXJhdGlvbixEQz1hZCxEQz1zZXJjbyxEQz1jb20/Y2VydGlmaWNh
# dGVSZXZvY2F0aW9uTGlzdD9iYXNlP29iamVjdENsYXNzPWNSTERpc3RyaWJ1dGlv
# blBvaW50hjRodHRwOi8vY3JsLnNlcmNvLmNvbS9wa2kvU2VyY28lMjBJc3N1aW5n
# JTIwQ0EoMikuY3JsMIGgBggrBgEFBQcBAQSBkzCBkDAhBggrBgEFBQcwAYYVaHR0
# cDovL29jc3Auc2VyY28uY29tMD0GCCsGAQUFBzAChjFodHRwOi8vY3JsLnNlcmNv
# LmNvbS9wa2kvU2VyY28lMjBJc3N1aW5nJTIwQ0EuY3J0MCwGCCsGAQUFBzAChiBo
# dHRwOi8vY3JsLnNlcmNvLmNvbS9wa2kvKDIpLmNydDANBgkqhkiG9w0BAQsFAAOC
# AQEAX7/mvXF6uGVn1gp87fDsItiuOwR0aZ60pRd0JzPM1SYyeOa8Gw9AFYWgQ/i6
# 8ZR8mQo89TMDFUbgV/XLdH/5pRQ1XruHJ3ITJlJ2ivts2GTc3xssckOPrronnpP5
# Dv8v2UCWkl3SuGNOYyMbBPl/3MmHu/j2bXJ7RdKSesoBtjfEDEj82NlPaVxYW1pb
# lKQwH5ldVo6QKiEZy4uEUk7vbUZn9n+cmfVZuskKmmOOi7gul687KYUeuwBoq8GJ
# yqunq3TqfQHHsNtSunsxdnISbtAMdakEM3k8rZkSuKQjU7CIHPrxqHD5hIAYaGBE
# Ah+K0LJOEJZgNWH2tw0PjfXhmDCCBq4wggSWoAMCAQICEAc2N7ckVHzYR6z9KGYq
# XlswDQYJKoZIhvcNAQELBQAwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lD
# ZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGln
# aUNlcnQgVHJ1c3RlZCBSb290IEc0MB4XDTIyMDMyMzAwMDAwMFoXDTM3MDMyMjIz
# NTk1OVowYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTsw
# OQYDVQQDEzJEaWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVT
# dGFtcGluZyBDQTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAMaGNQZJ
# s8E9cklRVcclA8TykTepl1Gh1tKD0Z5Mom2gsMyD+Vr2EaFEFUJfpIjzaPp985yJ
# C3+dH54PMx9QEwsmc5Zt+FeoAn39Q7SE2hHxc7Gz7iuAhIoiGN/r2j3EF3+rGSs+
# QtxnjupRPfDWVtTnKC3r07G1decfBmWNlCnT2exp39mQh0YAe9tEQYncfGpXevA3
# eZ9drMvohGS0UvJ2R/dhgxndX7RUCyFobjchu0CsX7LeSn3O9TkSZ+8OpWNs5KbF
# Hc02DVzV5huowWR0QKfAcsW6Th+xtVhNef7Xj3OTrCw54qVI1vCwMROpVymWJy71
# h6aPTnYVVSZwmCZ/oBpHIEPjQ2OAe3VuJyWQmDo4EbP29p7mO1vsgd4iFNmCKseS
# v6De4z6ic/rnH1pslPJSlRErWHRAKKtzQ87fSqEcazjFKfPKqpZzQmiftkaznTqj
# 1QPgv/CiPMpC3BhIfxQ0z9JMq++bPf4OuGQq+nUoJEHtQr8FnGZJUlD0UfM2SU2L
# INIsVzV5K6jzRWC8I41Y99xh3pP+OcD5sjClTNfpmEpYPtMDiP6zj9NeS3YSUZPJ
# jAw7W4oiqMEmCPkUEBIDfV8ju2TjY+Cm4T72wnSyPx4JduyrXUZ14mCjWAkBKAAO
# hFTuzuldyF4wEr1GnrXTdrnSDmuZDNIztM2xAgMBAAGjggFdMIIBWTASBgNVHRMB
# Af8ECDAGAQH/AgEAMB0GA1UdDgQWBBS6FtltTYUvcyl2mi91jGogj57IbzAfBgNV
# HSMEGDAWgBTs1+OC0nFdZEzfLmc/57qYrhwPTzAOBgNVHQ8BAf8EBAMCAYYwEwYD
# VR0lBAwwCgYIKwYBBQUHAwgwdwYIKwYBBQUHAQEEazBpMCQGCCsGAQUFBzABhhho
# dHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQQYIKwYBBQUHMAKGNWh0dHA6Ly9jYWNl
# cnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290RzQuY3J0MEMGA1Ud
# HwQ8MDowOKA2oDSGMmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRy
# dXN0ZWRSb290RzQuY3JsMCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwH
# ATANBgkqhkiG9w0BAQsFAAOCAgEAfVmOwJO2b5ipRCIBfmbW2CFC4bAYLhBNE88w
# U86/GPvHUF3iSyn7cIoNqilp/GnBzx0H6T5gyNgL5Vxb122H+oQgJTQxZ822EpZv
# xFBMYh0MCIKoFr2pVs8Vc40BIiXOlWk/R3f7cnQU1/+rT4osequFzUNf7WC2qk+R
# Zp4snuCKrOX9jLxkJodskr2dfNBwCnzvqLx1T7pa96kQsl3p/yhUifDVinF2ZdrM
# 8HKjI/rAJ4JErpknG6skHibBt94q6/aesXmZgaNWhqsKRcnfxI2g55j7+6adcq/E
# x8HBanHZxhOACcS2n82HhyS7T6NJuXdmkfFynOlLAlKnN36TU6w7HQhJD5TNOXrd
# /yVjmScsPT9rp/Fmw0HNT7ZAmyEhQNC3EyTN3B14OuSereU0cZLXJmvkOHOrpgFP
# vT87eK1MrfvElXvtCl8zOYdBeHo46Zzh3SP9HSjTx/no8Zhf+yvYfvJGnXUsHics
# JttvFXseGYs2uJPU5vIXmVnKcPA3v5gA3yAWTyf7YGcWoWa63VXAOimGsJigK+2V
# Qbc61RWYMbRiCQ8KvYHZE/6/pNHzV9m8BPqC3jLfBInwAM1dwvnQI38AC+R2AibZ
# 8GV2QqYphwlHK+Z/GqSFD/yYlvZVVCsfgPrA8g4r5db7qS9EFUrnEw4d2zc4GqEr
# 9u3WfPwwgga8MIIEpKADAgECAhALrma8Wrp/lYfG+ekE4zMEMA0GCSqGSIb3DQEB
# CwUAMGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkG
# A1UEAxMyRGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3Rh
# bXBpbmcgQ0EwHhcNMjQwOTI2MDAwMDAwWhcNMzUxMTI1MjM1OTU5WjBCMQswCQYD
# VQQGEwJVUzERMA8GA1UEChMIRGlnaUNlcnQxIDAeBgNVBAMTF0RpZ2lDZXJ0IFRp
# bWVzdGFtcCAyMDI0MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvmpz
# n/aVIauWMLpbbeZZo7Xo/ZEfGMSIO2qZ46XB/QowIEMSvgjEdEZ3v4vrrTHleW1J
# WGErrjOL0J4L0HqVR1czSzvUQ5xF7z4IQmn7dHY7yijvoQ7ujm0u6yXF2v1CrzZo
# pykD07/9fpAT4BxpT9vJoJqAsP8YuhRvflJ9YeHjes4fduksTHulntq9WelRWY++
# TFPxzZrbILRYynyEy7rS1lHQKFpXvo2GePfsMRhNf1F41nyEg5h7iOXv+vjX0K8R
# hUisfqw3TTLHj1uhS66YX2LZPxS4oaf33rp9HlfqSBePejlYeEdU740GKQM7SaVS
# H3TbBL8R6HwX9QVpGnXPlKdE4fBIn5BBFnV+KwPxRNUNK6lYk2y1WSKour4hJN0S
# MkoaNV8hyyADiX1xuTxKaXN12HgR+8WulU2d6zhzXomJ2PleI9V2yfmfXSPGYanG
# gxzqI+ShoOGLomMd3mJt92nm7Mheng/TBeSA2z4I78JpwGpTRHiT7yHqBiV2ngUI
# yCtd0pZ8zg3S7bk4QC4RrcnKJ3FbjyPAGogmoiZ33c1HG93Vp6lJ415ERcC7bFQM
# RbxqrMVANiav1k425zYyFMyLNyE1QulQSgDpW9rtvVcIH7WvG9sqYup9j8z9J1Xq
# bBZPJ5XLln8mS8wWmdDLnBHXgYly/p1DhoQo5fkCAwEAAaOCAYswggGHMA4GA1Ud
# DwEB/wQEAwIHgDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMI
# MCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATAfBgNVHSMEGDAWgBS6
# FtltTYUvcyl2mi91jGogj57IbzAdBgNVHQ4EFgQUn1csA3cOKBWQZqVjXu5Pkh92
# oFswWgYDVR0fBFMwUTBPoE2gS4ZJaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNybDCB
# kAYIKwYBBQUHAQEEgYMwgYAwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2lj
# ZXJ0LmNvbTBYBggrBgEFBQcwAoZMaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29t
# L0RpZ2lDZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNy
# dDANBgkqhkiG9w0BAQsFAAOCAgEAPa0eH3aZW+M4hBJH2UOR9hHbm04IHdEoT8/T
# 3HuBSyZeq3jSi5GXeWP7xCKhVireKCnCs+8GZl2uVYFvQe+pPTScVJeCZSsMo1JC
# oZN2mMew/L4tpqVNbSpWO9QGFwfMEy60HofN6V51sMLMXNTLfhVqs+e8haupWiAr
# SozyAmGH/6oMQAh078qRh6wvJNU6gnh5OruCP1QUAvVSu4kqVOcJVozZR5RRb/zP
# d++PGE3qF1P3xWvYViUJLsxtvge/mzA75oBfFZSbdakHJe2BVDGIGVNVjOp8sNt7
# 0+kEoMF+T6tptMUNlehSR7vM+C13v9+9ZOUKzfRUAYSyyEmYtsnpltD/GWX8eM70
# ls1V6QG/ZOB6b6Yum1HvIiulqJ1Elesj5TMHq8CWT/xrW7twipXTJ5/i5pkU5E16
# RSBAdOp12aw8IQhhA/vEbFkEiF2abhuFixUDobZaA0VhqAsMHOmaT3XThZDNi5U2
# zHKhUs5uHHdG6BoQau75KiNbh0c+hatSF+02kULkftARjsyEpHKsF7u5zKRbt5oK
# 5YGwFvgc4pEVUNytmB3BpIiowOIIuDgP5M9WArHYSAR16gc0dP2XdkMEP5eBsX7b
# f/MGN4K3HP50v/01ZHo/Z5lGLvNwQ7XHBx1yomzLP8lx4Q1zZKDyHcp4VQJLu2kW
# TsKsOqQxggU/MIIFOwIBATB6MGMxCzAJBgNVBAYTAkdCMRIwEAYDVQQIEwlIYW1w
# c2hpcmUxDTALBgNVBAcTBEhvb2sxFjAUBgNVBAoTDVNlcmNvIExpbWl0ZWQxGTAX
# BgNVBAMTEFNlcmNvIElzc3VpbmcgQ0ECE28AC5qj+JVunISx6+0AAgALmqMwCQYF
# Kw4DAhoFAKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkD
# MQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJ
# KoZIhvcNAQkEMRYEFH/xXYXBbjIXpjFOATLrDKvju7caMA0GCSqGSIb3DQEBAQUA
# BIIBAJ1cjkJdW/SpsrJF9Egkj6RPg0Iw/a2M3SDL9Dud/HkEVhbi07hZ8+zm1P2o
# gvMMYPQsic7uuxZ9PgJ45BxwZt5O/602aJmpZDbQq0TwHJpWtr3RhbNeL1JLc8dp
# DF0UFXqps5/RgdT/wFegdOsSRZUZ5ZK7DteANVZhP5Tt5eKDgooQfHVcs/Lmj23x
# YUA7Jv8TH8PM7jkVvp62zwdSyhLS5oCwawgl1iw/cgdgkOOaTMsWqo8HOOWBZjLK
# fGDrLFsIB/uGkdWnzjTZ+eF0v7BfHsltSonDntArFzCZQbN1rindww9B+LRyqo8V
# WhZ25d/2RVNVHuiXbD/Zi/eDobChggMgMIIDHAYJKoZIhvcNAQkGMYIDDTCCAwkC
# AQEwdzBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5
# BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0
# YW1waW5nIENBAhALrma8Wrp/lYfG+ekE4zMEMA0GCWCGSAFlAwQCAQUAoGkwGAYJ
# KoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjQxMDMwMTEz
# MzM1WjAvBgkqhkiG9w0BCQQxIgQgUTs0ofqknEWXfRgia/C5Eo/dniumVzoVCNfs
# LX4q2OYwDQYJKoZIhvcNAQEBBQAEggIAMPrYqVbY3mHTEVOc6MxK6CgD97OOJgic
# zTSMZ8/5PqYNyOx1ztB1h1eiW8R8/Fn1up//T7mR1xYITpaQdFPmOfpu4waf/Tev
# 0dOfoTFOFlrfSin1DyWRBYy9syfqCANAFXKRpPwzlp8nv8DA8NVpKaex2cwbLgA8
# B9QRKynMHH/3zocNvq7THSjGjPI2hJSNEC/PPg+pkq/++MYgUVTcfaMpci31aYPA
# X76ndAafU9nPPuxH7dYU2hBox6yg92eKFhr01tcbnsA5ZZrG52rgvmlqH2jhURDZ
# jfIMTj6hCTbd+z9Xy1GTYuDWwclKdPTTuK4ZQmZRIx4oD/w9G7waQkuncxB94uc6
# Btml7wWZaIImnzpvTb+Z1Iz7iVXy6d3blfKCpfnKvjzt/7nuVzx1PEQ5SgoG92JW
# Sh1sg4ECfrrw/FP9zgbIdxsgoGkjxI3RqqQ6GM0DiSdLogzcoQdlYJRugBkAB3wg
# IAx6yUT4XIsANTpxFwbJK35UtfqHV6YSaNsHiIg76WJ+zg4SiI7g01ROoVfrs2Up
# 8zXIPKtZ6rp3LgrqAGr7cNzsNrq8NxZe81X06ZaVdavHii/UpvWLf7tX1CjS9UQ2
# 76jHRMEJsagpLwRESEQXv4dPlz55/A+5uc3ZR0iMVgIgjw/OftBou310VVwqpksR
# +cGKjpjzgtQ=
# SIG # End signature block
