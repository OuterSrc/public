configuration AddSessionHost
{
    param
    (
        [Parameter(Mandatory = $true)]
        [string]$HostPoolName,

        [Parameter(Mandatory = $false)]
        [string]$RegistrationInfoToken = "",

        [Parameter(Mandatory = $false)]
        [PSCredential]$RegistrationInfoTokenCredential = $null,

        [Parameter(Mandatory = $false)]
        [bool]$AadJoin = $false,

        [Parameter(Mandatory = $false)]
        [bool]$AadJoinPreview = $false,

        [Parameter(Mandatory = $false)]
        [string]$MdmId = "",

        [Parameter(Mandatory = $false)]
        [string]$SessionHostConfigurationLastUpdateTime = "",

        [Parameter(Mandatory = $false)]
        [bool]$EnableVerboseMsiLogging = $false,
        
        [Parameter(Mandatory = $false)]
        [bool]$UseAgentDownloadEndpoint = $false
    )

    $ErrorActionPreference = 'Stop'
    
    $ScriptPath = [system.io.path]::GetDirectoryName($PSCommandPath)
    . (Join-Path $ScriptPath "Functions.ps1")

    $rdshIsServer = isRdshServer

    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }

        if ($rdshIsServer)
        {
            "$(get-date) - rdshIsServer = true: $rdshIsServer" | out-file c:\windows\temp\rdshIsServerResult.txt -Append
            WindowsFeature RDS-RD-Server
            {
                Ensure = "Present"
                Name = "RDS-RD-Server"
            }

            Script ExecuteRdAgentInstallServer
            {
                DependsOn = "[WindowsFeature]RDS-RD-Server"
                GetScript = {
                    return @{'Result' = ''}
                }
                SetScript = {
                    . (Join-Path $using:ScriptPath "Functions.ps1")
                    try {
                        & "$using:ScriptPath\Script-SetupSessionHost.ps1" -HostPoolName $using:HostPoolName -RegistrationInfoToken $using:RegistrationInfoToken -RegistrationInfoTokenCredential $using:RegistrationInfoTokenCredential -AadJoin $using:AadJoin -AadJoinPreview $using:AadJoinPreview -MdmId $using:MdmId -SessionHostConfigurationLastUpdateTime $using:SessionHostConfigurationLastUpdateTime -UseAgentDownloadEndpoint $using:UseAgentDownloadEndpoint -EnableVerboseMsiLogging:($using:EnableVerboseMsiLogging)
                    }
                    catch {
                        $ErrMsg = $PSItem | Format-List -Force | Out-String
                        Write-Log -Err $ErrMsg
                        throw [System.Exception]::new("Some error occurred in DSC ExecuteRdAgentInstallServer SetScript: $ErrMsg", $PSItem.Exception)
                    }
                }
                TestScript = {
                    . (Join-Path $using:ScriptPath "Functions.ps1")
                    
                    try {
                        return (& "$using:ScriptPath\Script-TestSetupSessionHost.ps1" -HostPoolName $using:HostPoolName)
                    }
                    catch {
                        $ErrMsg = $PSItem | Format-List -Force | Out-String
                        Write-Log -Err $ErrMsg
                        throw [System.Exception]::new("Some error occurred in DSC ExecuteRdAgentInstallServer TestScript: $ErrMsg", $PSItem.Exception)
                    }
                }
            }
        }
        else
        {
            "$(get-date) - rdshIsServer = false: $rdshIsServer" | out-file c:\windows\temp\rdshIsServerResult.txt -Append
            Script ExecuteRdAgentInstallClient
            {
                GetScript = {
                    return @{'Result' = ''}
                }
                SetScript = {
                    . (Join-Path $using:ScriptPath "Functions.ps1")
                    try {
                        & "$using:ScriptPath\Script-SetupSessionHost.ps1" -HostPoolName $using:HostPoolName -RegistrationInfoToken $using:RegistrationInfoToken -RegistrationInfoTokenCredential $using:RegistrationInfoTokenCredential -AadJoin $using:AadJoin -AadJoinPreview $using:AadJoinPreview -MdmId $using:MdmId -SessionHostConfigurationLastUpdateTime $using:SessionHostConfigurationLastUpdateTime -UseAgentDownloadEndpoint $using:UseAgentDownloadEndpoint -EnableVerboseMsiLogging:($using:EnableVerboseMsiLogging)
                    }
                    catch {
                        $ErrMsg = $PSItem | Format-List -Force | Out-String
                        Write-Log -Err $ErrMsg
                        throw [System.Exception]::new("Some error occurred in DSC ExecuteRdAgentInstallClient SetScript: $ErrMsg", $PSItem.Exception)
                    }
                }
                TestScript = {
                    . (Join-Path $using:ScriptPath "Functions.ps1")
                    
                    try {
                        return (& "$using:ScriptPath\Script-TestSetupSessionHost.ps1" -HostPoolName $using:HostPoolName)
                    }
                    catch {
                        $ErrMsg = $PSItem | Format-List -Force | Out-String
                        Write-Log -Err $ErrMsg
                        throw [System.Exception]::new("Some error occurred in DSC ExecuteRdAgentInstallClient TestScript: $ErrMsg", $PSItem.Exception)
                    }

                }
            }
        }
    }
}
# SIG # Begin signature block
# MIIlJAYJKoZIhvcNAQcCoIIlFTCCJRECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUckFARcPu51zU/zArrcuzT5Pk
# VTaggh9PMIIFjTCCBHWgAwIBAgIQDpsYjvnQLefv21DiCEAYWjANBgkqhkiG9w0B
# AQwFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVk
# IElEIFJvb3QgQ0EwHhcNMjIwODAxMDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQsw
# CQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cu
# ZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz
# 7MKnJS7JIT3yithZwuEppz1Yq3aaza57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS
# 5F/WBTxSD1Ifxp4VpX6+n6lXFllVcq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7
# bXHiLQwb7iDVySAdYyktzuxeTsiT+CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfI
# SKhmV1efVFiODCu3T6cw2Vbuyntd463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jH
# trHEtWoYOAMQjdjUN6QuBX2I9YI+EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14
# Ztk6MUSaM0C/CNdaSaTC5qmgZ92kJ7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2
# h4mXaXpI8OCiEhtmmnTK3kse5w5jrubU75KSOp493ADkRSWJtppEGSt+wJS00mFt
# 6zPZxd9LBADMfRyVw4/3IbKyEbe7f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPR
# iQfhvbfmQ6QYuKZ3AeEPlAwhHbJUKSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ER
# ElvlEFDrMcXKchYiCd98THU/Y+whX8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4K
# Jpn15GkvmB0t9dmpsh3lGwIDAQABo4IBOjCCATYwDwYDVR0TAQH/BAUwAwEB/zAd
# BgNVHQ4EFgQU7NfjgtJxXWRM3y5nP+e6mK4cD08wHwYDVR0jBBgwFoAUReuir/SS
# y4IxLVGLp6chnfNtyA8wDgYDVR0PAQH/BAQDAgGGMHkGCCsGAQUFBwEBBG0wazAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAC
# hjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURS
# b290Q0EuY3J0MEUGA1UdHwQ+MDwwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0
# LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwEQYDVR0gBAowCDAGBgRV
# HSAAMA0GCSqGSIb3DQEBDAUAA4IBAQBwoL9DXFXnOF+go3QbPbYW1/e/Vwe9mqyh
# hyzshV6pGrsi+IcaaVQi7aSId229GhT0E0p6Ly23OO/0/4C5+KH38nLeJLxSA8hO
# 0Cre+i1Wz/n096wwepqLsl7Uz9FDRJtDIeuWcqFItJnLnU+nBgMTdydE1Od/6Fmo
# 8L8vC6bp8jQ87PcDx4eo0kxAGTVGamlUsLihVo7spNU96LHc/RzY9HdaXFSMb++h
# UD38dglohJ9vytsgjTVgHAIDyyCwrFigDkBjxZgiwbJZ9VVrzyerbHbObyMt9H5x
# aiNrIv8SuFQtJ37YOtnwtoeW/VvRXKwYw02fc7cBqZ9Xql4o4rmUMIIFpDCCA4yg
# AwIBAgITdAAAABpPBOS2mfHAGQAAAAAAGjANBgkqhkiG9w0BAQsFADBYMQswCQYD
# VQQGEwJHQjESMBAGA1UECBMJSGFtcHNoaXJlMQ0wCwYDVQQHEwRIb29rMQ4wDAYD
# VQQKEwVTZXJjbzEWMBQGA1UEAxMNU2VyY28gUm9vdCBDQTAeFw0yMjA2MDkxMDE2
# MzNaFw0yNzA2MDkxMDI2MzNaMGMxCzAJBgNVBAYTAkdCMRIwEAYDVQQIEwlIYW1w
# c2hpcmUxDTALBgNVBAcTBEhvb2sxFjAUBgNVBAoTDVNlcmNvIExpbWl0ZWQxGTAX
# BgNVBAMTEFNlcmNvIElzc3VpbmcgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQDAtf9WJtHH7DloaVM0zB1GDEALn3dDd86dBXRZ9cctclEWSsmr1kY3
# yf2Ew8agE8QSeQUZcYZ/S8mlPAVE9fTpDUn92b5t2GwC66orDq5kvffmI6AshAAg
# N38AgPi/hjsxVh9zhaxWoAdT2xLPQkCRb6fAqwYfsw6LZ+x+qZuxkGH9Yljof/6N
# zG67nNt1FX0gvNG/321oEP5debj3GI0YNLFwI3sjCB8GH0O6lxht67Ei/8Rrnlii
# O36uUQb1eu48jzmTEeG7f2eBHlPeWUpgOaxp8kuu3lr7DEje94sZLoUJH8k6jgLG
# ikwXPtuU/Nc9ZDMLbs/ExD/Zn+PSFdBxAgMBAAGjggFaMIIBVjASBgkrBgEEAYI3
# FQEEBQIDAgACMCMGCSsGAQQBgjcVAgQWBBT3gaQvzowOaVbp+y3c1gvaOZfjYjAd
# BgNVHQ4EFgQUopXkhtwaDrY4TYaDWoCALa/cfDcwGQYJKwYBBAGCNxQCBAweCgBT
# AHUAYgBDAEEwDgYDVR0PAQH/BAQDAgEGMBIGA1UdEwEB/wQIMAYBAf8CAQAwHwYD
# VR0jBBgwFoAURolT3VYsBjsVcN3hsf2ipkZICcAwNgYDVR0fBC8wLTAroCmgJ4Yl
# aHR0cDovL2NybC5zZXJjby5jb20vcGtpL3NlcmNvaWNhLmNybDBkBggrBgEFBQcB
# AQRYMFYwIQYIKwYBBQUHMAGGFWh0dHA6Ly9vY3NwLnNlcmNvLmNvbTAxBggrBgEF
# BQcwAoYlaHR0cDovL2NybC5zZXJjby5jb20vcGtpL3NlcmNvaWNhLmNydDANBgkq
# hkiG9w0BAQsFAAOCAgEAAVK7Zv3vR1Kh+g/NSAH30qVBtZwGjtGGGyqLLdqF5i/e
# 0FQVWpIalwheMbsGwcg//3hUgbKYgtiNcQSXJdgxCPa2LQFYgRGLhgYqpzr5smw9
# Lr3fg0uV1TJ3Y9eW3ucF0BSPjS2LHey0iSNODQjfdkiV3sjJx5tzCcPA3+FcQmRs
# xIHXcmAh4slCNUbJSrQarbGE/LXnox/YFxUjMOHDaWc4ocEBf+OGLpO5fuoEtoxK
# S/yBqS7y6f4ULM9SxYmVMjqn8U6z/BTSWqn/twKbmnqEkjM2SKzmBoy833xXJW8G
# qTuynBE+dvlWK1jgtVIAPqEXksDTU643Cnm46oFjGPWjnM8HvA/O2h4gbd0bQ/pF
# nec8aMujwIXEr3dJNXJ/e9YOWlQm3aTGaaFLuW5N+yD4r6y7YyP0DLsT2/MQbeBx
# cb9mNU/WWA+SMVfBUxkKfho097X0tdwSrNjSGK+BfwjVWvMBXF+xVg3AS75ajD28
# 5fbJWcOp/vlb/xLjR7R5E38rFg2bpLbMWheuoZU51F8kh/ho9MjMT07mxCdgqD9g
# GLjAbE5jmZcdS6jG/ShRJAkQG0kBDqdowMayYv+WytUJPA0IL4QM0Q1sf19BEHYT
# hggb6jZmAh+iWQdUmym5MRSb2WdAV7SPP0s+w2umte3SKZtcuVHNKynBp74ExCYw
# ggagMIIFiKADAgECAhNvAAuao/iVbpyEsevtAAIAC5qjMA0GCSqGSIb3DQEBCwUA
# MGMxCzAJBgNVBAYTAkdCMRIwEAYDVQQIEwlIYW1wc2hpcmUxDTALBgNVBAcTBEhv
# b2sxFjAUBgNVBAoTDVNlcmNvIExpbWl0ZWQxGTAXBgNVBAMTEFNlcmNvIElzc3Vp
# bmcgQ0EwHhcNMjQxMDE0MTM0NzI2WhcNMjYxMDE0MTM0NzI2WjCBpjETMBEGCgmS
# JomT8ixkARkWA2NvbTEVMBMGCgmSJomT8ixkARkWBXNlcmNvMRIwEAYKCZImiZPy
# LGQBGRYCYWQxFzAVBgNVBAsTDkFkbWluaXN0cmF0aW9uMRkwFwYDVQQLExBTZXJ2
# aWNlIEFjY291bnRzMRowGAYDVQQLExFDeWJlckFyayBBY2NvdW50czEUMBIGA1UE
# AxMLQ1lBLWhzYW5kaHUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDt
# QSJKVFfrt6XVZdqtkCLASSvo+VTV4tDAlUjk2Bqe3VL86GUPo7sDLHBMqVno7iad
# Ib8OjnyRDlEpzi972GxSxfJR+qYAZetnN1ei6aBMlf5sk7++LnokK0geNvdn+a30
# pf9PZlZ9BV2h9jcc+o7KWeerf+s7Tjui0l2cP2SgOat6UBVq0pPYLC3D8YIQXXkB
# 1VgPyJfIfKTXgo5Abxvm/4DM6vfovq14AIvouxemKl+D72DgCdkvZ4VKqBm+/xeK
# zv+ajO5p6pjOeXsIJioppxKZsnmWrDYLjQTdKfey4hoY665jbQQBPB5pdeAg4lc9
# XRGBUY+dD7NrpgFqoo+NAgMBAAGjggMHMIIDAzA8BgkrBgEEAYI3FQcELzAtBiUr
# BgEEAYI3FQiB/cN8hvGYZ4GxhQWH8rBJhvjmBzeHutB3ysIpAgFkAgEdMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMDMAsGA1UdDwQEAwIHgDAbBgkrBgEEAYI3FQoEDjAMMAoG
# CCsGAQUFBwMDME8GCSsGAQQBgjcZAgRCMECgPgYKKwYBBAGCNxkCAaAwBC5TLTEt
# NS0yMS0xMTkyMjUwOTM1LTM2OTc4MzQzLTM5NDU5OTc2NzctNzc0MzMzMDAGA1Ud
# EQQpMCegJQYKKwYBBAGCNxQCA6AXDBVDWUEtaHNhbmRodUBzZXJjby5jb20wHQYD
# VR0OBBYEFGYf+t3epHraX3XW2J6ik8miwB1gMB8GA1UdIwQYMBaAFKKV5IbcGg62
# OE2Gg1qAgC2v3Hw3MIIBHAYDVR0fBIIBEzCCAQ8wggELoIIBB6CCAQOGgcpsZGFw
# Oi8vL0NOPVNlcmNvJTIwSXNzdWluZyUyMENBKDIpLENOPVNDT1NHVEM1UEVDQTEw
# MSxDTj1DRFAsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMs
# Q049Q29uZmlndXJhdGlvbixEQz1hZCxEQz1zZXJjbyxEQz1jb20/Y2VydGlmaWNh
# dGVSZXZvY2F0aW9uTGlzdD9iYXNlP29iamVjdENsYXNzPWNSTERpc3RyaWJ1dGlv
# blBvaW50hjRodHRwOi8vY3JsLnNlcmNvLmNvbS9wa2kvU2VyY28lMjBJc3N1aW5n
# JTIwQ0EoMikuY3JsMIGgBggrBgEFBQcBAQSBkzCBkDAhBggrBgEFBQcwAYYVaHR0
# cDovL29jc3Auc2VyY28uY29tMD0GCCsGAQUFBzAChjFodHRwOi8vY3JsLnNlcmNv
# LmNvbS9wa2kvU2VyY28lMjBJc3N1aW5nJTIwQ0EuY3J0MCwGCCsGAQUFBzAChiBo
# dHRwOi8vY3JsLnNlcmNvLmNvbS9wa2kvKDIpLmNydDANBgkqhkiG9w0BAQsFAAOC
# AQEAX7/mvXF6uGVn1gp87fDsItiuOwR0aZ60pRd0JzPM1SYyeOa8Gw9AFYWgQ/i6
# 8ZR8mQo89TMDFUbgV/XLdH/5pRQ1XruHJ3ITJlJ2ivts2GTc3xssckOPrronnpP5
# Dv8v2UCWkl3SuGNOYyMbBPl/3MmHu/j2bXJ7RdKSesoBtjfEDEj82NlPaVxYW1pb
# lKQwH5ldVo6QKiEZy4uEUk7vbUZn9n+cmfVZuskKmmOOi7gul687KYUeuwBoq8GJ
# yqunq3TqfQHHsNtSunsxdnISbtAMdakEM3k8rZkSuKQjU7CIHPrxqHD5hIAYaGBE
# Ah+K0LJOEJZgNWH2tw0PjfXhmDCCBq4wggSWoAMCAQICEAc2N7ckVHzYR6z9KGYq
# XlswDQYJKoZIhvcNAQELBQAwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lD
# ZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGln
# aUNlcnQgVHJ1c3RlZCBSb290IEc0MB4XDTIyMDMyMzAwMDAwMFoXDTM3MDMyMjIz
# NTk1OVowYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTsw
# OQYDVQQDEzJEaWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVT
# dGFtcGluZyBDQTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAMaGNQZJ
# s8E9cklRVcclA8TykTepl1Gh1tKD0Z5Mom2gsMyD+Vr2EaFEFUJfpIjzaPp985yJ
# C3+dH54PMx9QEwsmc5Zt+FeoAn39Q7SE2hHxc7Gz7iuAhIoiGN/r2j3EF3+rGSs+
# QtxnjupRPfDWVtTnKC3r07G1decfBmWNlCnT2exp39mQh0YAe9tEQYncfGpXevA3
# eZ9drMvohGS0UvJ2R/dhgxndX7RUCyFobjchu0CsX7LeSn3O9TkSZ+8OpWNs5KbF
# Hc02DVzV5huowWR0QKfAcsW6Th+xtVhNef7Xj3OTrCw54qVI1vCwMROpVymWJy71
# h6aPTnYVVSZwmCZ/oBpHIEPjQ2OAe3VuJyWQmDo4EbP29p7mO1vsgd4iFNmCKseS
# v6De4z6ic/rnH1pslPJSlRErWHRAKKtzQ87fSqEcazjFKfPKqpZzQmiftkaznTqj
# 1QPgv/CiPMpC3BhIfxQ0z9JMq++bPf4OuGQq+nUoJEHtQr8FnGZJUlD0UfM2SU2L
# INIsVzV5K6jzRWC8I41Y99xh3pP+OcD5sjClTNfpmEpYPtMDiP6zj9NeS3YSUZPJ
# jAw7W4oiqMEmCPkUEBIDfV8ju2TjY+Cm4T72wnSyPx4JduyrXUZ14mCjWAkBKAAO
# hFTuzuldyF4wEr1GnrXTdrnSDmuZDNIztM2xAgMBAAGjggFdMIIBWTASBgNVHRMB
# Af8ECDAGAQH/AgEAMB0GA1UdDgQWBBS6FtltTYUvcyl2mi91jGogj57IbzAfBgNV
# HSMEGDAWgBTs1+OC0nFdZEzfLmc/57qYrhwPTzAOBgNVHQ8BAf8EBAMCAYYwEwYD
# VR0lBAwwCgYIKwYBBQUHAwgwdwYIKwYBBQUHAQEEazBpMCQGCCsGAQUFBzABhhho
# dHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQQYIKwYBBQUHMAKGNWh0dHA6Ly9jYWNl
# cnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290RzQuY3J0MEMGA1Ud
# HwQ8MDowOKA2oDSGMmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRy
# dXN0ZWRSb290RzQuY3JsMCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwH
# ATANBgkqhkiG9w0BAQsFAAOCAgEAfVmOwJO2b5ipRCIBfmbW2CFC4bAYLhBNE88w
# U86/GPvHUF3iSyn7cIoNqilp/GnBzx0H6T5gyNgL5Vxb122H+oQgJTQxZ822EpZv
# xFBMYh0MCIKoFr2pVs8Vc40BIiXOlWk/R3f7cnQU1/+rT4osequFzUNf7WC2qk+R
# Zp4snuCKrOX9jLxkJodskr2dfNBwCnzvqLx1T7pa96kQsl3p/yhUifDVinF2ZdrM
# 8HKjI/rAJ4JErpknG6skHibBt94q6/aesXmZgaNWhqsKRcnfxI2g55j7+6adcq/E
# x8HBanHZxhOACcS2n82HhyS7T6NJuXdmkfFynOlLAlKnN36TU6w7HQhJD5TNOXrd
# /yVjmScsPT9rp/Fmw0HNT7ZAmyEhQNC3EyTN3B14OuSereU0cZLXJmvkOHOrpgFP
# vT87eK1MrfvElXvtCl8zOYdBeHo46Zzh3SP9HSjTx/no8Zhf+yvYfvJGnXUsHics
# JttvFXseGYs2uJPU5vIXmVnKcPA3v5gA3yAWTyf7YGcWoWa63VXAOimGsJigK+2V
# Qbc61RWYMbRiCQ8KvYHZE/6/pNHzV9m8BPqC3jLfBInwAM1dwvnQI38AC+R2AibZ
# 8GV2QqYphwlHK+Z/GqSFD/yYlvZVVCsfgPrA8g4r5db7qS9EFUrnEw4d2zc4GqEr
# 9u3WfPwwgga8MIIEpKADAgECAhALrma8Wrp/lYfG+ekE4zMEMA0GCSqGSIb3DQEB
# CwUAMGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkG
# A1UEAxMyRGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3Rh
# bXBpbmcgQ0EwHhcNMjQwOTI2MDAwMDAwWhcNMzUxMTI1MjM1OTU5WjBCMQswCQYD
# VQQGEwJVUzERMA8GA1UEChMIRGlnaUNlcnQxIDAeBgNVBAMTF0RpZ2lDZXJ0IFRp
# bWVzdGFtcCAyMDI0MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvmpz
# n/aVIauWMLpbbeZZo7Xo/ZEfGMSIO2qZ46XB/QowIEMSvgjEdEZ3v4vrrTHleW1J
# WGErrjOL0J4L0HqVR1czSzvUQ5xF7z4IQmn7dHY7yijvoQ7ujm0u6yXF2v1CrzZo
# pykD07/9fpAT4BxpT9vJoJqAsP8YuhRvflJ9YeHjes4fduksTHulntq9WelRWY++
# TFPxzZrbILRYynyEy7rS1lHQKFpXvo2GePfsMRhNf1F41nyEg5h7iOXv+vjX0K8R
# hUisfqw3TTLHj1uhS66YX2LZPxS4oaf33rp9HlfqSBePejlYeEdU740GKQM7SaVS
# H3TbBL8R6HwX9QVpGnXPlKdE4fBIn5BBFnV+KwPxRNUNK6lYk2y1WSKour4hJN0S
# MkoaNV8hyyADiX1xuTxKaXN12HgR+8WulU2d6zhzXomJ2PleI9V2yfmfXSPGYanG
# gxzqI+ShoOGLomMd3mJt92nm7Mheng/TBeSA2z4I78JpwGpTRHiT7yHqBiV2ngUI
# yCtd0pZ8zg3S7bk4QC4RrcnKJ3FbjyPAGogmoiZ33c1HG93Vp6lJ415ERcC7bFQM
# RbxqrMVANiav1k425zYyFMyLNyE1QulQSgDpW9rtvVcIH7WvG9sqYup9j8z9J1Xq
# bBZPJ5XLln8mS8wWmdDLnBHXgYly/p1DhoQo5fkCAwEAAaOCAYswggGHMA4GA1Ud
# DwEB/wQEAwIHgDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMI
# MCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATAfBgNVHSMEGDAWgBS6
# FtltTYUvcyl2mi91jGogj57IbzAdBgNVHQ4EFgQUn1csA3cOKBWQZqVjXu5Pkh92
# oFswWgYDVR0fBFMwUTBPoE2gS4ZJaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNybDCB
# kAYIKwYBBQUHAQEEgYMwgYAwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2lj
# ZXJ0LmNvbTBYBggrBgEFBQcwAoZMaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29t
# L0RpZ2lDZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNy
# dDANBgkqhkiG9w0BAQsFAAOCAgEAPa0eH3aZW+M4hBJH2UOR9hHbm04IHdEoT8/T
# 3HuBSyZeq3jSi5GXeWP7xCKhVireKCnCs+8GZl2uVYFvQe+pPTScVJeCZSsMo1JC
# oZN2mMew/L4tpqVNbSpWO9QGFwfMEy60HofN6V51sMLMXNTLfhVqs+e8haupWiAr
# SozyAmGH/6oMQAh078qRh6wvJNU6gnh5OruCP1QUAvVSu4kqVOcJVozZR5RRb/zP
# d++PGE3qF1P3xWvYViUJLsxtvge/mzA75oBfFZSbdakHJe2BVDGIGVNVjOp8sNt7
# 0+kEoMF+T6tptMUNlehSR7vM+C13v9+9ZOUKzfRUAYSyyEmYtsnpltD/GWX8eM70
# ls1V6QG/ZOB6b6Yum1HvIiulqJ1Elesj5TMHq8CWT/xrW7twipXTJ5/i5pkU5E16
# RSBAdOp12aw8IQhhA/vEbFkEiF2abhuFixUDobZaA0VhqAsMHOmaT3XThZDNi5U2
# zHKhUs5uHHdG6BoQau75KiNbh0c+hatSF+02kULkftARjsyEpHKsF7u5zKRbt5oK
# 5YGwFvgc4pEVUNytmB3BpIiowOIIuDgP5M9WArHYSAR16gc0dP2XdkMEP5eBsX7b
# f/MGN4K3HP50v/01ZHo/Z5lGLvNwQ7XHBx1yomzLP8lx4Q1zZKDyHcp4VQJLu2kW
# TsKsOqQxggU/MIIFOwIBATB6MGMxCzAJBgNVBAYTAkdCMRIwEAYDVQQIEwlIYW1w
# c2hpcmUxDTALBgNVBAcTBEhvb2sxFjAUBgNVBAoTDVNlcmNvIExpbWl0ZWQxGTAX
# BgNVBAMTEFNlcmNvIElzc3VpbmcgQ0ECE28AC5qj+JVunISx6+0AAgALmqMwCQYF
# Kw4DAhoFAKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkD
# MQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJ
# KoZIhvcNAQkEMRYEFCtSJLQUkA4h6XTHCtN5piBqurI/MA0GCSqGSIb3DQEBAQUA
# BIIBAOmULUElZo3ANw+JV36hBwymgpR+HKHURs9W0VfmzRnXL8bKTjPLxAOPTplm
# l7ClI2Go7AvPXeJUpBRVRqp2Wqr3J1j49HCUg5biJWacOHexGh1JHQEsJijE10H8
# ZUbEmP4+0jiOhx2UdfGdAQnHRBiObtyLpiSp+A8WqMTvmSWN7bMPT5Z/aNj3oi0J
# W1fzBmE9l6UdJjKUnAPiD6jO0DiTpSTE55Hothh/hzDrw7bs4WLvasNpTPXL8508
# DIiVqZN8O0J/MsDxHmXOdtznnmIkANrI4UvCPeHo3V8DlRXmGv8lABFlpmCrTcNu
# mn+dcwEh3U9CzvDKkNAJRSJOyTChggMgMIIDHAYJKoZIhvcNAQkGMYIDDTCCAwkC
# AQEwdzBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5
# BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0
# YW1waW5nIENBAhALrma8Wrp/lYfG+ekE4zMEMA0GCWCGSAFlAwQCAQUAoGkwGAYJ
# KoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjQxMDMwMTA0
# MDA1WjAvBgkqhkiG9w0BCQQxIgQgpSuRjsjqfsGUrjuIkx/IoAi+FR1CqRyA87ef
# sz3XGfowDQYJKoZIhvcNAQEBBQAEggIAV9pfx4vTtnk83+Vp1Ksucg8rZ7HoQTkr
# qVGXrkA4EoktEzJHsaBB/XjpsrxazJda3YBU5r3DE0Yr+SELlGNx6a8UTx0YOPch
# zcm/SsfJH8IRn+fEMvg9Q2NsdNw5hI+J3CodMAjwhgETa+aeA4DVPVR6Fl80D9d+
# U5YtrppWMGPxqbo2jliCSpi4U0gOLzRtsAYC15Px/8xm3fDaLVnvwz0X95dx2jwQ
# 26q7Kq91JIsTabKCUl7SebLbtXwzANF5+GrPmKwyMTWxFsVrdOZeL/Qy2R9W2YIn
# I1DDLiWjOqkRuc0OIHuwvXWraOnQuHyA1BSJPJ6yMEgLJ/uzbXY3PUcb5ze5A5Ea
# NMNjXGlxQO376//4V9l7I6od6886uoDcUFznKd6Gtf9psg4hjApFnLFJSWu2hh/A
# hPn5XZxnvYME32s2zGZrFsBmhih5rIRyBKYwGafCX8x3uE6MHzM3BOCS+ZsWts8e
# QjoExv/WMZyUW+xde7IOOyCUgOR1YD4VgcdRsN00vcSGmIpkG35Anhi5dgU/wi4I
# +NIe6128rAPrZsRLoWhY06PImyY2iuWQcXVJfkINZOyF8ymPKR3mtQchGExBX7M3
# /NPmwkmTsfbVV5EpC9P9spnlQNZ6ShDKNk7vah7GLfeuXmhdSEp/x0CscFZu+R74
# QgXbFBve+0I=
# SIG # End signature block
